//app/index.js

const calc = require('./calc.js');
const numbersToAdd = [
	3,
	4,
	10,
	2
];

const result = calc.sum(numbersToAdd);
console.log(`The result is: ${result}`);
